import en from './en.json';
import pl from './pl.json';
import ru from './ru.json';

export default {
  en: { ...en },
  pl: { ...pl },
  ru: { ...ru },
};
