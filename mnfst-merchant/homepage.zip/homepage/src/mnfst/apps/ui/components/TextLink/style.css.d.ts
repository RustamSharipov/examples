export const textLink: string;
export const hasUnderline: string;
export const greyTheme: string;
export const sandTheme: string;
export const violetTheme: string;
export const whiteTheme: string;
