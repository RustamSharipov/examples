export const textInputContainer: string;
export const isHover: string;
export const hasFocus: string;
export const hasErrors: string;
export const dockTop: string;
export const dockBottom: string;
export const dockRight: string;
export const dockLeft: string;
