export const secondaryNavigation: string;
export const secondaryNavigationItem: string;
export const control: string;
