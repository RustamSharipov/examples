export const mnfstPopupPreloader: string;
export const isHidden: string;
export const logo: string;
export const darkTheme: string;
