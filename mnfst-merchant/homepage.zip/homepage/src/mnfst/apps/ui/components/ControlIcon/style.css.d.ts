export const controlIcon: string;
export const hasPointerEvents: string;
export const appendBefore: string;
export const appendAfter: string;
