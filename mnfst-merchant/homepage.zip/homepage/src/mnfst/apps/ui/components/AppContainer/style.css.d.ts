export const appContainer: string;
