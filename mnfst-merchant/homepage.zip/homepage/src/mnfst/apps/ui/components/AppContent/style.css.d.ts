export const appContent: string;
