export const error: string;
export const code: string;
export const description: string;
