export const accordionItemTitle: string;
export const accordionItemContent: string;
export const accordionItem: string;
export const isExpanded: string;
