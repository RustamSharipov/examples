export const leftDirection: string;
export const rightDirection: string;
export const topDirection: string;
