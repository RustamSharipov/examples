export const sandwichMenu: string;
export const isActive: string;
