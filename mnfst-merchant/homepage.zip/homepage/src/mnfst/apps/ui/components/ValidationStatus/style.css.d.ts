export const validationStatus: string;
export const isDisplay: string;
export const errorType: string;
export const successType: string;
