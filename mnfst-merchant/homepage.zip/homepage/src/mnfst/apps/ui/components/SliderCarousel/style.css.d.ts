export const sliderCarousel: string;
