export const logo: string;
