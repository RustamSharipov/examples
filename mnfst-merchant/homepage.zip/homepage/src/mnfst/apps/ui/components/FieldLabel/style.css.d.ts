export const label: string;
export const notEmptyValue: string;
