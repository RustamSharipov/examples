export const navigation: string;
export const navigationItems: string;
export const navigationItem: string;
export const control: string;
export const isActive: string;
export const isHighlighted: string;
export const link: string;
export const frontTheme: string;
