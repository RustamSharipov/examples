export const socialNetworksGroups: string;
export const socialNetwork: string;
export const socialNetworkIcon: string;
export const darkTheme: string;
