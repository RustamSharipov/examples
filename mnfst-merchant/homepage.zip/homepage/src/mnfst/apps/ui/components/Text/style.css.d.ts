export const textStub: string;
