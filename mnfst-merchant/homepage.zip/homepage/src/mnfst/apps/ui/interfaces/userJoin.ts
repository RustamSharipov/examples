import { IFormField } from 'apps/ui/interfaces/form';

export interface IJoin {
  phone_number: IFormField<string>;
}
