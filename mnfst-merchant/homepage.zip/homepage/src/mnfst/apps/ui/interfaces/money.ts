export interface IMoney {
  currency_code: string;
  value: number;
}
