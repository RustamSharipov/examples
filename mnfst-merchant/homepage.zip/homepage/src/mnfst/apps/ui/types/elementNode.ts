export type ImageRelation = 'horizontal' | 'square' | 'vertical' | null;
