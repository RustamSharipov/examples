export const links: string;
