export const backgroundLayer: string;
export const waveContainer: string;
export const wave: string;
export const swell: string;
