export const description: string;
