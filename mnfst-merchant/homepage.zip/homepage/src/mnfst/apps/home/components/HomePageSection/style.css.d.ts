export const homepageSectionTitle: string;
export const homepageSectionDescription: string;
export const homepageSectionContent: string;
export const homepageSection: string;
export const isRevealed: string;
