export const partnerBrandLogo: string;
export const partnerBrandLogoImage: string;
export const partnerBrandsLogos: string;
export const horizontalRelation: string;
export const verticalRelation: string;
