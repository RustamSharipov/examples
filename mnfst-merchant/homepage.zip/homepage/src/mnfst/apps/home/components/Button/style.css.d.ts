export const button: string;
export const smallSize: string;
