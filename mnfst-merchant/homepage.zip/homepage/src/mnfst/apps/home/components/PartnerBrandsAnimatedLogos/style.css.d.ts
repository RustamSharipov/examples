export const partnerBrandsAnimatedLogos: string;
export const partnerBrandsAnimatedLogosInversed: string;
export const partnerBrandsAnimatedLogosWrapper: string;
export const partnerFirstElement: string;
