export const header: string;
export const app: string;
