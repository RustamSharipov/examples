export const footer: string;
export const link: string;
export const app: string;
export const socialNetwork: string;
