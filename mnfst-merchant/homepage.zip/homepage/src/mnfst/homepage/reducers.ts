import home from 'apps/home/reducers/home';
import userLocation from 'apps/ui/reducers/userLocation';

const reducers = {
  home,
  userLocation,
};

export default reducers;
